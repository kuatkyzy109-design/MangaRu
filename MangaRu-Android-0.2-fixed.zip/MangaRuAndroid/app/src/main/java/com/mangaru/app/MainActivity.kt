package com.mangaru.app

import android.os.Bundle
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        web=findViewById(R.id.web); status=findViewById(R.id.status)
        val url=findViewById<EditText>(R.id.url); val auto=findViewById<Switch>(R.id.auto)
        web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.loadsImagesAutomatically=true
        web.webViewClient=object:WebViewClient(){ override fun onPageFinished(v:WebView,u:String){ if(auto.isChecked) installScanner(); status.text="Загружено • AUTO ${if(auto.isChecked) "ON" else "OFF"}" } }
        findViewById<Button>(R.id.go).setOnClickListener { var u=url.text.toString().trim(); if(!u.startsWith("http"))u="https://$u"; web.loadUrl(u) }
        auto.setOnCheckedChangeListener{_,on->if(on)installScanner() else web.evaluateJavascript("window.__mangaruInstalled=false",null)}
    }
    private fun installScanner(){
        web.addJavascriptInterface(object{ @JavascriptInterface fun found(src:String){runOnUiThread{status.text="Найдена страница • OCR/перевод готовится"}}},"MangaRuBridge")
        val js="""(function(){if(window.__mangaruInstalled)return;window.__mangaruInstalled=true;var seen=new WeakSet();var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting||seen.has(e.target))return;var i=e.target,r=i.getBoundingClientRect();if(r.width<180||r.height<180)return;seen.add(i);window.MangaRuBridge.found(i.currentSrc||i.src);});},{rootMargin:'1200px'});document.querySelectorAll('img').forEach(function(i){io.observe(i)});new MutationObserver(function(){document.querySelectorAll('img').forEach(function(i){io.observe(i)})}).observe(document.documentElement,{childList:true,subtree:true});})();"""
        web.evaluateJavascript(js,null)
    }
    fun translate(text:String,tag:String,done:(String)->Unit){
        val id=LanguageIdentification.getClient(); id.identifyLanguage(text).addOnSuccessListener{detected->
            val src=TranslateLanguage.fromLanguageTag(if(tag=="auto")detected else tag)?:TranslateLanguage.ENGLISH
            val tr=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(TranslateLanguage.RUSSIAN).build())
            tr.downloadModelIfNeeded().addOnSuccessListener{tr.translate(text).addOnSuccessListener(done).addOnCompleteListener{tr.close();id.close()}}
        }
    }
}
