package com.mangaru.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            status.text = "Захват экрана не разрешён"
            return@registerForActivityResult
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Разреши показ поверх других приложений и нажми запуск ещё раз"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return@registerForActivityResult
        }
        val intent = Intent(this, ScreenTranslationService::class.java).apply {
            action = ScreenTranslationService.ACTION_START
            putExtra(ScreenTranslationService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(ScreenTranslationService.EXTRA_RESULT_DATA, result.data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Автоперевод запущен"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.start).setOnClickListener { startTranslation() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopService(Intent(this, ScreenTranslationService::class.java)) }
    }

    private fun startTranslation() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Сначала разреши показ поверх других приложений"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 50)
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        status.text = "Разреши MangaRu захватывать экран"
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}
