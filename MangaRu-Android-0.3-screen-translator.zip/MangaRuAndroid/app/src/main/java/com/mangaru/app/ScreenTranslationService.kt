package com.mangaru.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.nl.translate.*
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class ScreenTranslationService : Service() {
    companion object {
        const val ACTION_START = "com.mangaru.app.START"
        const val ACTION_STOP = "com.mangaru.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "mangaru_translation"
        private const val NOTIFICATION_ID = 42
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TranslationOverlay? = null
    private val busy = AtomicBoolean(false)
    private var lastHash = 0L
    private var lastProcess = 0L
    private var density = 1

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
            val data = intent.parcelable<Intent>(EXTRA_RESULT_DATA) ?: return START_NOT_STICKY
            startForegroundServiceNotification()
            startCapture(code, data)
        }
        return START_STICKY
    }

    private fun startForegroundServiceNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "MangaRu", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("MangaRu: автоперевод включён")
            .setContentText("Распознаём текст на экране")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NOTIFICATION_ID, n)
    }

    private fun startCapture(code: Int, data: Intent) {
        if (projection != null) return
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = pm.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        density = metrics.densityDpi
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastProcess < 1400 || busy.get()) { r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastProcess = now
            executor.execute { processImage(image) }
        }, Handler(Looper.getMainLooper()))
        display = projection!!.createVirtualDisplay("MangaRu", w, h, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        overlay = TranslationOverlay(this).also { it.show() }
    }

    private fun processImage(image: Image) {
        if (!busy.compareAndSet(false, true)) { image.close(); return }
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            val hash = quickHash(bitmap)
            if (hash == lastHash) return
            lastHash = hash
            val input = InputImage.fromBitmap(bitmap, 0)
            val recognizers = listOf(
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
                TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
                TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            )
            // Start with Latin OCR; Japanese/Korean are tried only if little Latin text is found.
            recognizers[0].process(input).addOnSuccessListener { latin ->
                if (latin.text.length >= 3) handleText(latin, bitmap.width, bitmap.height)
                else recognizers[1].process(input).addOnSuccessListener { jp ->
                    if (jp.text.length >= 3) handleText(jp, bitmap.width, bitmap.height)
                    else recognizers[2].process(input).addOnSuccessListener { ko -> handleText(ko, bitmap.width, bitmap.height) }
                        .addOnCompleteListener { recognizers.forEach { it.close() } }
                }.addOnCompleteListener { if (latin.text.length >= 3) recognizers.forEach { it.close() } }
            }.addOnFailureListener { recognizers.forEach { it.close() } }
        } catch (_: Exception) { image.close() } finally { busy.set(false) }
    }

    private fun handleText(result: Text, width: Int, height: Int) {
        val lines = result.textBlocks.flatMap { it.lines }.filter { it.text.trim().length >= 2 }.take(18)
        if (lines.isEmpty()) return
        val translatorCache = HashMap<String, Translator>()
        val pending = lines.size
        val translated = arrayOfNulls<TranslationBox>(lines.size)
        val lock = Any()
        var done = 0
        lines.forEachIndexed { index, line ->
            val source = detectSource(line.text)
            val tr = translatorCache.getOrPut(source) {
                Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TranslateLanguage.RUSSIAN).build())
            }
            tr.downloadModelIfNeeded().continueWithTask { tr.translate(line.text) }
                .addOnSuccessListener { txt ->
                    val b = line.boundingBox ?: Rect(0,0,0,0)
                    translated[index] = TranslationBox(txt, b)
                }.addOnCompleteListener {
                    synchronized(lock) { done++ ; if (done == pending) { overlay?.update(translated.filterNotNull()) ; translatorCache.values.forEach { it.close() } } }
                }
        }
    }

    private fun detectSource(text: String): String {
        return when {
            text.any { it in '\u3040'..'\u30ff' } -> TranslateLanguage.JAPANESE
            text.any { it in '\uac00'..'\ud7af' } -> TranslateLanguage.KOREAN
            else -> TranslateLanguage.ENGLISH
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val fullWidth = image.width + rowPadding / pixelStride
        val temp = Bitmap.createBitmap(fullWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        temp.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(temp, 0, 0, image.width, image.height)
    }

    private fun quickHash(b: Bitmap): Long {
        var h = 1125899906842597L
        val stepX = max(1, b.width / 32); val stepY = max(1, b.height / 32)
        for (y in 0 until b.height step stepY) for (x in 0 until b.width step stepX) h = 31*h + b.getPixel(x,y)
        return h
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); overlay?.hide(); executor.shutdownNow(); super.onDestroy()
    }

    private inline fun <reified T: android.os.Parcelable> Intent.parcelable(key:String):T? = if(Build.VERSION.SDK_INT>=33) getParcelableExtra(key,T::class.java) else @Suppress("DEPRECATION") getParcelableExtra(key)
}

data class TranslationBox(val text:String, val rect:Rect)

class TranslationOverlay(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val view = OverlayView(context)
    private var attached = false
    fun show(){
        if(attached || !Settings.canDrawOverlays(context)) return
        val type = if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.START
        wm.addView(view,p); attached=true
    }
    fun update(boxes:List<TranslationBox>){ view.post { view.boxes=boxes; view.invalidate() } }
    fun hide(){ if(attached){wm.removeView(view);attached=false} }
}

class OverlayView(context: Context): View(context) {
    var boxes:List<TranslationBox> = emptyList()
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=34f;typeface=Typeface.DEFAULT}
    override fun onDraw(c:Canvas){
        super.onDraw(c)
        for(b in boxes){
            val r=b.rect
            paint.color=Color.argb(225,255,255,255); c.drawRoundRect(r.left.toFloat(),r.top.toFloat(),r.right.toFloat(),r.bottom.toFloat(),12f,12f,paint)
            val maxW=(r.width()-16).coerceAtLeast(80).toFloat()
            val parts=split(b.text,maxW)
            var y=r.top+textPaint.textSize
            for(s in parts){ c.drawText(s,r.left+8,y,textPaint); y+=textPaint.textSize+4 }
        }
    }
    private fun split(s:String,maxW:Float):List<String>{
        val out= mutableListOf<String>(); var cur=""
        for(ch in s){ val n=cur+ch; if(textPaint.measureText(n)>maxW && cur.isNotEmpty()){out+=cur;cur="$ch"} else cur=n }
        if(cur.isNotEmpty())out+=cur; return out
    }
}
